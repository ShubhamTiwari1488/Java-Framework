package com.highradius.actions;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import com.opensymphony.xwork2.util.ValueStack;

@SuppressWarnings("serial")
public class MyInterceptor implements Interceptor{

	@Override
	public void destroy() {
		System.out.println("Destroyed!!!");
	}

	@Override
	public void init() {
		System.out.println("Init method called!!!");
	}

	@Override
	public String intercept(ActionInvocation arg0) throws Exception {
		ValueStack stack = arg0.getStack();
		String s = stack.findString("name");
		
		stack.set("name",s.toUpperCase());
		
		return arg0.invoke();
	}
	
}
